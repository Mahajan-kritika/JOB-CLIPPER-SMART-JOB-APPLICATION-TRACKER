const STORAGE_KEY = 'jobClipperJobs';
const PREFERENCES_KEY = 'jobClipperPreferences';
const STATUS_ORDER = ['SAVED', 'APPLIED', 'INTERVIEW', 'RESULT'];

const statsGrid = document.getElementById('stats-grid');
const searchInput = document.getElementById('search-input');
const statusFilter = document.getElementById('status-filter');
const deadlineFilter = document.getElementById('deadline-filter');
const sortOrder = document.getElementById('sort-order');
const exportButton = document.getElementById('export-csv');
const openPopupButton = document.getElementById('open-popup');
const modal = document.getElementById('job-modal');
const detailForm = document.getElementById('job-detail-form');
const closeModalButton = document.getElementById('close-modal');

let allJobs = [];
let currentSelectedJobId = null;

function readJobs() {
  return new Promise((resolve) => {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      allJobs = [];
      resolve(allJobs);
      return;
    }

    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const jobs = Array.isArray(result[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
      allJobs = jobs.filter(Boolean);
      resolve(allJobs);
    });
  });
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

function getDeadlineState(job) {
  if (!job.deadline) return 'NONE';
  const date = new Date(job.deadline);
  if (Number.isNaN(date.getTime())) return 'NONE';

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const deadlineDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  if (deadlineDate < today) return 'OVERDUE';
  if (deadlineDate.getTime() === today.getTime()) return 'TODAY';
  const diffDays = Math.ceil((deadlineDate - today) / 86400000);
  return diffDays <= 7 ? 'UPCOMING' : 'FUTURE';
}

function buildStats(jobs) {
  const total = jobs.length;
  const applied = jobs.filter((job) => job.status === 'APPLIED').length;
  const interviews = jobs.filter((job) => job.status === 'INTERVIEW').length;
  const results = jobs.filter((job) => job.status === 'RESULT').length;
  const upcoming = jobs.filter((job) => {
    const state = getDeadlineState(job);
    return state === 'UPCOMING' || state === 'TODAY';
  }).length;

  const cards = [
    { label: 'Total Jobs', value: total },
    { label: 'Applied', value: applied },
    { label: 'Interviews', value: interviews },
    { label: 'Results', value: results },
    { label: 'Upcoming Deadlines', value: upcoming },
  ];

  statsGrid.innerHTML = cards.map((card) => `
    <article class="stat-card">
      <div class="label">${card.label}</div>
      <div class="value">${card.value}</div>
    </article>
  `).join('');
}

function sortJobs(jobs) {
  const query = searchInput.value.trim().toLowerCase();
  const status = statusFilter.value;
  const deadline = deadlineFilter.value;

  const filtered = jobs.filter((job) => {
    const matchesQuery = !query || [job.title, job.companyName, job.location, job.notes].join(' ').toLowerCase().includes(query);
    const matchesStatus = status === 'ALL' || job.status === status;
    const deadlineState = getDeadlineState(job);
    const matchesDeadline = deadline === 'ALL' ||
      (deadline === 'UPCOMING' && (deadlineState === 'UPCOMING' || deadlineState === 'TODAY')) ||
      (deadline === 'OVERDUE' && deadlineState === 'OVERDUE');
    return matchesQuery && matchesStatus && matchesDeadline;
  });

  const comparatorMap = {
    recent: (a, b) => new Date(b.dateSaved || b.createdAt || 0) - new Date(a.dateSaved || a.createdAt || 0),
    oldest: (a, b) => new Date(a.dateSaved || a.createdAt || 0) - new Date(b.dateSaved || b.createdAt || 0),
    deadline: (a, b) => {
      const aDate = a.deadline ? new Date(a.deadline).getTime() : Number.MAX_SAFE_INTEGER;
      const bDate = b.deadline ? new Date(b.deadline).getTime() : Number.MAX_SAFE_INTEGER;
      return aDate - bDate;
    },
    alphabetical: (a, b) => (a.title || '').localeCompare(b.title || '') || (a.companyName || '').localeCompare(b.companyName || ''),
  };

  return filtered.sort(comparatorMap[sortOrder.value] || comparatorMap.recent);
}

function renderBoard() {
  const jobs = sortJobs(allJobs);
  buildStats(allJobs);

  for (const status of STATUS_ORDER) {
    const list = document.getElementById(`list-${status}`);
    const countBadge = document.getElementById(`count-${status}`);
    const items = jobs.filter((job) => job.status === status);
    list.innerHTML = items.map((job) => {
      const deadlineText = job.deadline ? `Deadline: ${formatDate(job.deadline)}` : 'Deadline: —';
      const statusBadge = job.status;
      return `
        <article class="job-card" data-id="${job.id}" draggable="true" aria-label="${job.title} for ${job.companyName}">
          <h3>${escapeHtml(job.title || 'Untitled Role')}</h3>
          <div class="company">${escapeHtml(job.companyName || 'Unknown company')}</div>
          <div class="job-item-meta">
            <span>${escapeHtml(job.location || 'Location N/A')}</span>
            <span>${escapeHtml(deadlineText)}</span>
            <span>${escapeHtml(statusBadge)}</span>
          </div>
        </article>
      `;
    }).join('') || '<div class="empty-placeholder">No jobs in this column</div>';

    countBadge.textContent = String(items.length);
  }

  attachCardEvents();
  attachDragAndDrop();
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function attachCardEvents() {
  document.querySelectorAll('.job-card').forEach((card) => {
    card.addEventListener('click', () => {
      const id = card.dataset.id;
      const job = allJobs.find((item) => item.id === id);
      if (!job) return;
      currentSelectedJobId = job.id;
      fillDetailForm(job);
      modal.classList.remove('hidden');
    });
  });
}

function attachDragAndDrop() {
  const cards = document.querySelectorAll('.job-card');
  cards.forEach((card) => {
    card.addEventListener('dragstart', () => {
      card.classList.add('dragging');
      card.dataset.dragging = 'true';
    });

    card.addEventListener('dragend', () => {
      card.classList.remove('dragging');
      card.dataset.dragging = 'false';
    });
  });

  document.querySelectorAll('.column').forEach((column) => {
    column.addEventListener('dragover', (event) => {
      event.preventDefault();
      column.style.borderColor = '#3b82f6';
    });

    column.addEventListener('dragleave', () => {
      column.style.borderColor = '';
    });

    column.addEventListener('drop', (event) => {
      event.preventDefault();
      const dragged = document.querySelector('.job-card.dragging');
      const nextStatus = column.dataset.status;
      column.style.borderColor = '';
      if (!dragged) return;

      const id = dragged.dataset.id;
      const job = allJobs.find((item) => item.id === id);
      if (!job || !nextStatus) return;
      job.status = nextStatus;
      persistJobs();
      renderBoard();
    });
  });
}

function fillDetailForm(job) {
  document.getElementById('detail-title').value = job.title || '';
  document.getElementById('detail-company').value = job.companyName || '';
  document.getElementById('detail-url').value = job.jobUrl || '';
  document.getElementById('detail-location').value = job.location || '';
  document.getElementById('detail-description').value = job.description || '';
  document.getElementById('detail-salary').value = job.salary || '';
  document.getElementById('detail-employment-type').value = job.employmentType || '';
  document.getElementById('detail-deadline').value = job.deadline || '';
  document.getElementById('detail-status').value = job.status || 'SAVED';
  document.getElementById('detail-notes').value = job.notes || '';
}

function persistJobs() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    return;
  }

  chrome.storage.local.set({ [STORAGE_KEY]: allJobs }, () => {
    renderBoard();
  });
}

closeModalButton.addEventListener('click', () => {
  modal.classList.add('hidden');
  currentSelectedJobId = null;
});

modal.addEventListener('click', (event) => {
  if (event.target.dataset.closeModal === 'true') {
    modal.classList.add('hidden');
  }
});

detailForm.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!currentSelectedJobId) return;

  const found = allJobs.find((job) => job.id === currentSelectedJobId);
  if (!found) return;

  found.title = document.getElementById('detail-title').value.trim();
  found.companyName = document.getElementById('detail-company').value.trim();
  found.jobUrl = document.getElementById('detail-url').value.trim();
  found.location = document.getElementById('detail-location').value.trim();
  found.description = document.getElementById('detail-description').value.trim();
  found.salary = document.getElementById('detail-salary').value.trim();
  found.employmentType = document.getElementById('detail-employment-type').value.trim();
  found.deadline = document.getElementById('detail-deadline').value;
  found.status = document.getElementById('detail-status').value;
  found.notes = document.getElementById('detail-notes').value.trim();

  persistJobs();
  modal.classList.add('hidden');
});

document.getElementById('delete-job').addEventListener('click', () => {
  if (!currentSelectedJobId) return;
  const confirmed = window.confirm('Are you sure you want to permanently delete this job?');
  if (!confirmed) return;

  allJobs = allJobs.filter((job) => job.id !== currentSelectedJobId);
  persistJobs();
  modal.classList.add('hidden');
});

document.getElementById('open-original-link').addEventListener('click', () => {
  if (!currentSelectedJobId) return;
  const found = allJobs.find((job) => job.id === currentSelectedJobId);
  if (!found || !found.jobUrl) return;
  window.open(found.jobUrl, '_blank', 'noopener');
});

exportButton.addEventListener('click', () => {
  const csvRows = [['Job Title', 'Company', 'Job URL', 'Location', 'Employment Type', 'Salary', 'Application Deadline', 'Date Saved', 'Application Status', 'Notes']];
  allJobs.forEach((job) => {
    csvRows.push([
      escapeCsv(job.title || ''),
      escapeCsv(job.companyName || ''),
      escapeCsv(job.jobUrl || ''),
      escapeCsv(job.location || ''),
      escapeCsv(job.employmentType || ''),
      escapeCsv(job.salary || ''),
      escapeCsv(job.deadline || ''),
      escapeCsv(job.dateSaved || ''),
      escapeCsv(job.status || 'SAVED'),
      escapeCsv(job.notes || '')
    ]);
  });

  const csvContent = csvRows.map((row) => row.join(',')).join('\n');
  const csvBlob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(csvBlob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'job-clipper-export.csv';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
});

function escapeCsv(value) {
  const stringValue = String(value ?? '');
  const escaped = stringValue.replace(/"/g, '""');
  return `"${escaped}"`;
}

openPopupButton.addEventListener('click', () => {
  if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.create) {
    window.open('../popup/popup.html', '_blank');
    return;
  }
  chrome.tabs.create({ url: chrome.runtime.getURL('popup/popup.html') });
});

searchInput.addEventListener('input', renderBoard);
statusFilter.addEventListener('change', renderBoard);
deadlineFilter.addEventListener('change', renderBoard);
sortOrder.addEventListener('change', renderBoard);

readJobs().then(renderBoard);
