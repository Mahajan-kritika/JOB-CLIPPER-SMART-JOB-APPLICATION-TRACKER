const STORAGE_KEY = 'jobClipperJobs';
const PREFERENCES_KEY = 'jobClipperPreferences';
const REMINDER_ALARM_NAME = 'jobClipperReminderCheck';

const defaultPreferences = {
  reminderOffsetHours: 24,
  notificationEnabled: true,
};

function getDefaultPreferences() {
  return { ...defaultPreferences };
}

function safeJsonParse(value, fallback) {
  try {
    return value === undefined || value === null ? fallback : JSON.parse(value);
  } catch (error) {
    return fallback;
  }
}

async function readJobs() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const jobs = Array.isArray(result[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
      resolve(jobs.filter(Boolean));
    });
  });
}

async function readPreferences() {
  return new Promise((resolve) => {
    chrome.storage.local.get([PREFERENCES_KEY], (result) => {
      const saved = result[PREFERENCES_KEY];
      resolve({ ...getDefaultPreferences(), ...(saved || {}) });
    });
  });
}

function formatDeadlineMessage(job) {
  const deadline = job.deadline ? new Date(job.deadline) : null;
  const label = Number.isNaN(deadline?.getTime()) ? 'Deadline' : deadline.toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return `${job.title || 'Application'} – ${job.companyName || 'Company'}\nDeadline: ${label}`;
}

function applyReminderToJobs(jobId, offsetHours) {
  return readJobs().then((jobs) => {
    const updatedJobs = jobs.map((item) => {
      if (item.id !== jobId) return item;
      return {
        ...item,
        reminderOffsetHours: Number.isFinite(Number(offsetHours)) ? Number(offsetHours) : Number(item.reminderOffsetHours ?? 24),
        lastReminderSentAt: new Date().toISOString(),
      };
    });
    return chrome.storage.local.set({ [STORAGE_KEY]: updatedJobs });
  });
}

function shouldSendReminder(job, now, offsetHours) {
  if (!job || !job.deadline || !job.title) return false;

  const deadlineDate = new Date(job.deadline);
  if (Number.isNaN(deadlineDate.getTime())) return false;

  const thresholdTime = new Date(deadlineDate.getTime() - (offsetHours * 60 * 60 * 1000));
  const reminderWasSent = job.lastReminderSentAt ? new Date(job.lastReminderSentAt) : null;

  if (now < thresholdTime) {
    return false;
  }

  if (now > deadlineDate) {
    return false;
  }

  if (!reminderWasSent) {
    return true;
  }

  return reminderWasSent.getTime() < thresholdTime.getTime();
}

async function sendNotificationForJob(job, offsetHours) {
  const preferences = await readPreferences();
  if (!preferences.notificationEnabled) return;

  const title = 'Application deadline approaching!';
  const message = formatDeadlineMessage(job);

  try {
    await chrome.notifications.create(`job-clipper-${job.id}`, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title,
      message,
      priority: 2,
    });

    await applyReminderToJobs(job.id, offsetHours);
  } catch (error) {
    console.error('Unable to send reminder notification', error);
  }
}

async function checkJobReminders() {
  const jobs = await readJobs();
  const preferences = await readPreferences();
  const now = new Date();

  for (const job of jobs) {
    const offsetHours = Number(job.reminderOffsetHours ?? preferences.reminderOffsetHours ?? 24);
    if (!shouldSendReminder(job, now, offsetHours)) continue;
    await sendNotificationForJob(job, offsetHours);
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === REMINDER_ALARM_NAME) {
    checkJobReminders();
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(REMINDER_ALARM_NAME, { periodInMinutes: 15 });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(REMINDER_ALARM_NAME, { periodInMinutes: 15 });
  checkJobReminders();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === 'GET_REMINDER_PREFERENCES') {
    readPreferences().then((preferences) => sendResponse({ preferences })).catch(() => sendResponse({ preferences: getDefaultPreferences() }));
    return true;
  }

  if (message && message.type === 'SAVE_REMINDER_PREFERENCES') {
    const incoming = { ...getDefaultPreferences(), ...(message.preferences || {}) };
    chrome.storage.local.set({ [PREFERENCES_KEY]: incoming }, () => {
      chrome.alarms.create(REMINDER_ALARM_NAME, { periodInMinutes: 15 });
      sendResponse({ ok: true, preferences: incoming });
    });
    return true;
  }

  if (message && message.type === 'CHECK_JOB_REMINDERS') {
    checkJobReminders();
    sendResponse({ ok: true });
    return true;
  }

  if (message && message.type === 'GET_STORAGE_STATE') {
    Promise.all([readJobs(), readPreferences()]).then(([jobs, preferences]) => {
      sendResponse({ jobs, preferences });
    }).catch(() => sendResponse({ jobs: [], preferences: getDefaultPreferences() }));
    return true;
  }

  return false;
});

chrome.alarms.create(REMINDER_ALARM_NAME, { periodInMinutes: 15 });
checkJobReminders();
