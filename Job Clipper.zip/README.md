# Job Clipper

Job Clipper is a Chrome Extension Manifest V3 project that helps job seekers save opportunities from job websites, track them in a Kanban workflow, monitor deadlines, and export everything into CSV.

## Features

- One-click extraction from job pages
- Manual job entry for unsupported pages
- Kanban board with Saved, Applied, Interview, and Result columns
- Search, filter, and sort controls
- Deadline reminders with Chrome notifications and `chrome.alarms`
- CSV export for all saved jobs
- Local persistence using `chrome.storage.local`
- Data editing and deletion with confirmation

## Installation

1. Open Chrome and navigate to `chrome://extensions`.
2. Enable Developer Mode.
3. Click `Load unpacked`.
4. Select the project folder containing `manifest.json`.
5. The extension is ready to use.

## Usage

- Click the Job Clipper extension icon in Chrome to open the popup.
- Use the automatically detected values from the current job page or edit the form manually.
- Save jobs to the local tracker.
- Open the dashboard to manage the Kanban board, search/filter jobs, edit details, and export CSV.
- Set or adjust a deadline to enable notifications before the application due date.

## Supported testing summary

The extension was designed for job-site compatibility and tested against common public listings such as:

- LinkedIn Jobs
- Indeed
- Internshala

The extraction logic relies on common selectors, Open Graph metadata, JSON-LD, and page text so it remains website-independent where possible.

## File structure

- `manifest.json` – Chrome Extension manifest
- `background.js` – reminders and alarm scheduler
- `content.js` – page extraction and page injection
- `styles.css` – shared styles
- `popup/` – quick-save popup
- `dashboard/` – Kanban dashboard
- `components/` – reusable card/form helpers
- `icons/` – extension icons

## Notes

- All data is stored locally in Chrome storage.
- Notifications require permission from Chrome the first time they are used.
- A reminder is by default scheduled 24 hours before the deadline and can be adjusted per saved job or globally.

## License

This project is intended for personal job-seeking workflow management and is ready to be used in Chrome Developer Mode.
