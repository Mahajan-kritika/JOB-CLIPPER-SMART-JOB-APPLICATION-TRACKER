const JOB_CLIPPER_MARKER = '__jobClipperButtonInjected';

function toText(node) {
  return node ? (node.textContent || '').replace(/\s+/g, ' ').trim() : '';
}

function getMetaContent(attributes) {
  for (const attribute of attributes) {
    const node = document.querySelector(`meta[${attribute}]`);
    if (node && node.getAttribute(attribute)) {
      return node.getAttribute(attribute).trim();
    }
  }

  for (const attribute of attributes) {
    const node = document.querySelector(`meta[name="${attribute}"]`);
    if (node && node.getAttribute('content')) {
      return node.getAttribute('content').trim();
    }
  }

  for (const attribute of attributes) {
    const node = document.querySelector(`meta[property="${attribute}"]`);
    if (node && node.getAttribute('content')) {
      return node.getAttribute('content').trim();
    }
  }

  return '';
}

function extractJsonLdData() {
  const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));

  for (const script of scripts) {
    try {
      const payload = JSON.parse(script.textContent || '');
      const items = Array.isArray(payload) ? payload : [payload];

      for (const item of items) {
        const stack = [item];
        while (stack.length) {
          const current = stack.pop();
          if (!current || typeof current !== 'object') continue;
          if (current['@type'] === 'JobPosting' || current['@type'] === 'Organization' || current['@type'] === 'Place') {
            return current;
          }
          for (const value of Object.values(current)) {
            if (Array.isArray(value)) stack.push(...value.filter(Boolean));
            else if (typeof value === 'object' && value !== null) stack.push(value);
          }
        }
      }
    } catch (error) {
      console.warn('Failed to parse JSON-LD on page', error);
    }
  }

  return {};
}

function normalizeDeadlineValue(value) {
  if (!value) return '';
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0, 10);
  const cleaned = String(value).trim();
  const match = cleaned.match(/(\d{4}-\d{2}-\d{2}|\d{1,2}[-/ ]\w+[-/ ]\d{4}|\w+\s+\d{1,2},\s*\d{4})/i);
  if (!match) return cleaned;
  return match[0];
}

function findTextBySelector(selectorList) {
  for (const selector of selectorList) {
    const node = document.querySelector(selector);
    if (node && toText(node)) return toText(node);
  }
  return '';
}

function findVisibleTextMatch(phrases) {
  const bodyText = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
  for (const phrase of phrases) {
    const regex = new RegExp(phrase.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'i');
    const match = bodyText.match(regex);
    if (match) return match[0];
  }
  return '';
}

function extractJobDataFromPage() {
  const jsonLd = extractJsonLdData();
  const canonicalUrl = document.querySelector('link[rel="canonical"]')?.href || getMetaContent(['og:url']);
  const fallbackUrl = location.href;

  const title = findTextBySelector([
    'h1',
    '[data-testid="job-title"]',
    '[data-qa="job-title"]',
    '[class*="job-title"]',
    '[class*="JobTitle"]',
    '.job-details__title',
  ]) || getMetaContent(['og:title', 'twitter:title']) || document.title || '';

  const company = findTextBySelector([
    '[data-testid="company-name"]',
    '[data-qa="company-name"]',
    '.job-details__company',
    '.job-search-card__company',
    '.company-name',
    '[class*="company-name"]',
  ]) || jsonLd.hiringOrganization?.name || jsonLd.hiringOrganization?.legalName || getMetaContent(['og:site_name']) || '';

  const location = findTextBySelector([
    '[data-testid="job-location"]',
    '[data-qa="job-location"]',
    '.job-details__location',
    '.job-location',
    '[class*="location"]',
  ]) || (jsonLd.jobLocation?.address ? `${jsonLd.jobLocation.address.addressLocality || ''} ${jsonLd.jobLocation.address.addressRegion || ''}`.trim() : '') || '';

  const employmentType = findTextBySelector([
    '[data-testid="job-type"]',
    '[data-qa="job-type"]',
    '.job-details__employment-type',
    '[class*="employment"]',
  ]) || (Array.isArray(jsonLd.employmentType) ? jsonLd.employmentType.join(', ') : jsonLd.employmentType) || '';

  const salary = findTextBySelector([
    '[data-testid="salary"]',
    '[data-qa="salary"]',
    '.salary',
    '[class*="salary"]',
  ]) || findVisibleTextMatch(['salary', 'compensation']) || (jsonLd.baseSalary ? `${jsonLd.baseSalary.value || ''} ${jsonLd.baseSalary.currency || ''}`.trim() : '') || '';

  const description = jsonLd.description || document.querySelector('meta[name="description"]')?.content || document.querySelector('meta[property="og:description"]')?.content || '';

  const deadline = normalizeDeadlineValue(
    jsonLd.applicationDeadline ||
    document.querySelector('meta[name="application_deadline"]')?.content ||
    findVisibleTextMatch(['Application deadline', 'Deadline', 'Closing date', 'Last date to apply']) ||
    ''
  );

  const companyWebsite = getMetaContent(['og:url']) || canonicalUrl || '';
  const url = canonicalUrl || fallbackUrl;

  return {
    title: title || getMetaContent(['og:title']) || document.title || '',
    companyName: company || '',
    jobUrl: url || '',
    companyWebsite,
    location,
    employmentType,
    salary,
    deadline,
    description: description || ''
  };
}

function createFloatingButton() {
  if (document.getElementById('job-clipper-floating-button') || document.body === null) {
    return;
  }

  const container = document.createElement('div');
  container.id = 'job-clipper-floating-button';
  container.style.position = 'fixed';
  container.style.right = '18px';
  container.style.bottom = '18px';
  container.style.zIndex = '2147483647';
  container.style.fontFamily = 'Segoe UI, sans-serif';

  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = 'Save This Job';
  button.style.background = '#0b1f3a';
  button.style.color = '#fff';
  button.style.border = 'none';
  button.style.borderRadius = '999px';
  button.style.padding = '12px 18px';
  button.style.fontSize = '14px';
  button.style.fontWeight = '600';
  button.style.cursor = 'pointer';
  button.style.boxShadow = '0 12px 30px rgba(11, 31, 58, 0.18)';

  button.addEventListener('click', () => {
    const payload = extractJobDataFromPage();
    chrome.storage.local.set({ jobClipperPageData: payload }, () => {
      const toast = document.createElement('div');
      toast.textContent = 'Job ready to save in Job Clipper';
      toast.style.position = 'fixed';
      toast.style.right = '18px';
      toast.style.bottom = '80px';
      toast.style.zIndex = '2147483647';
      toast.style.background = '#0f766e';
      toast.style.color = '#fff';
      toast.style.padding = '10px 15px';
      toast.style.borderRadius = '12px';
      toast.style.fontSize = '12px';
      toast.style.fontFamily = 'Segoe UI, sans-serif';
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 1800);
    });
  });

  container.appendChild(button);
  document.body.appendChild(container);
}

if (!window[JOB_CLIPPER_MARKER]) {
  window[JOB_CLIPPER_MARKER] = true;
  const observer = new MutationObserver(() => {
    if (document.body && !document.getElementById('job-clipper-floating-button')) {
      createFloatingButton();
    }
  });
  observer.observe(document.documentElement || document.body, { childList: true, subtree: true });
  createFloatingButton();
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === 'GET_PAGE_JOB_DATA') {
    sendResponse(extractJobDataFromPage());
    return true;
  }

  if (message && message.type === 'GET_PAGE_SNAPSHOT') {
    sendResponse({
      title: document.title,
      url: location.href,
      bodyText: (document.body?.innerText || '').slice(0, 1500),
    });
    return true;
  }

  return false;
});
