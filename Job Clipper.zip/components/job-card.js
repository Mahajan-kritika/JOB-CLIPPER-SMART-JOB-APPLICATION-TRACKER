(() => {
  const CARD_CLASS = 'job-card';

  function JobCard(job) {
    this.job = job;
    this.element = document.createElement('article');
    this.element.className = CARD_CLASS;
    this.element.innerHTML = `
      <h3>${job.title || 'Untitled Role'}</h3>
      <div class="company">${job.companyName || 'Unknown company'}</div>
      <div class="job-item-meta">
        <span>${job.location || 'Location N/A'}</span>
        <span>${job.deadline ? `Deadline: ${job.deadline}` : 'Deadline: —'}</span>
        <span>${job.status || 'SAVED'}</span>
      </div>
    `;
    return this.element;
  }

  window.JobCard = JobCard;
})();
