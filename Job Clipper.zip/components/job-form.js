(() => {
  const formTemplate = {
    title: '',
    companyName: '',
    jobUrl: '',
    location: '',
    description: '',
    employmentType: '',
    salary: '',
    deadline: '',
    notes: '',
    status: 'SAVED'
  };

  function JobForm() {
    this.state = { ...formTemplate };
    this.root = document.createElement('form');
    this.root.className = 'job-form';
    this.root.innerHTML = `
      <label><span>Job Title</span><input name="title" type="text" required /></label>
      <label><span>Company</span><input name="companyName" type="text" required /></label>
      <label><span>Job URL</span><input name="jobUrl" type="url" /></label>
      <label><span>Location</span><input name="location" type="text" /></label>
      <label><span>Job Description</span><textarea name="description" rows="4"></textarea></label>
      <label><span>Employment Type</span><input name="employmentType" type="text" /></label>
      <label><span>Salary</span><input name="salary" type="text" /></label>
      <label><span>Application Deadline</span><input name="deadline" type="date" /></label>
      <label><span>Application Notes</span><textarea name="notes" rows="3"></textarea></label>
      <label><span>Application Status</span><select name="status"><option>SAVED</option><option>APPLIED</option><option>INTERVIEW</option><option>RESULT</option></select></label>
      <button type="submit">Save Job</button>
    `;
    return this.root;
  }

  window.JobForm = JobForm;
})();
