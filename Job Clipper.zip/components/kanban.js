(() => {
  const STATUS_COLUMNS = ['SAVED', 'APPLIED', 'INTERVIEW', 'RESULT'];

  function KanbanBoard(container, jobs = []) {
    this.container = container;
    this.jobs = jobs;
    this.render();
  }

  KanbanBoard.prototype.render = function () {
    this.container.innerHTML = STATUS_COLUMNS.map((status) => `
      <section class="column" data-status="${status}">
        <div class="column-header">
          <h2>${status}</h2>
          <span class="count">${this.jobs.filter((job) => job.status === status).length}</span>
        </div>
        <div class="job-list"></div>
      </section>
    `).join('');
  };

  window.KanbanBoard = KanbanBoard;
})();
