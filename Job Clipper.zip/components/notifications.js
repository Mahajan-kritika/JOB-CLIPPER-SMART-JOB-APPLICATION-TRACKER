(() => {
  function showNotification(title, message) {
    if (!('Notification' in window)) {
      return;
    }

    if (Notification.permission === 'granted') {
      new Notification(title, { body: message });
    }
  }

  window.JobClipperNotifications = { showNotification };
})();
