const STORAGE_KEY = 'jobClipperJobs';
const PREFERENCES_KEY = 'jobClipperPreferences';
const defaultPreferences = { reminderOffsetHours: 24, notificationEnabled: true };

const form = document.getElementById('job-form');
const statusBanner = document.getElementById('status-banner');
const dashboardButton = document.getElementById('open-dashboard');
const saveButton = document.getElementById('save-job');

function showBanner(message, isError = false) {
  statusBanner.textContent = message;
  statusBanner.classList.toggle('error', isError);
  statusBanner.classList.remove('hidden');
}

function hideBanner() {
  statusBanner.classList.add('hidden');
}

function gatherFormData() {
  const formData = new FormData(form);
  return {
    title: (formData.get('title') || '').toString().trim(),
    companyName: (formData.get('companyName') || '').toString().trim(),
    location: (formData.get('location') || '').toString().trim(),
    jobUrl: (formData.get('jobUrl') || '').toString().trim(),
    employmentType: (formData.get('employmentType') || '').toString().trim(),
    salary: (formData.get('salary') || '').toString().trim(),
    deadline: (formData.get('deadline') || '').toString().trim(),
    description: (formData.get('description') || '').toString().trim(),
    status: (formData.get('status') || 'SAVED').toString().trim().toUpperCase(),
    reminderOffsetHours: Number((formData.get('reminderOffsetHours') || defaultPreferences.reminderOffsetHours).toString().trim()) || defaultPreferences.reminderOffsetHours,
    notes: (formData.get('notes') || '').toString().trim(),
  };
}

function setFormValues(data = {}) {
  document.getElementById('jobTitle').value = data.title || '';
  document.getElementById('companyName').value = data.companyName || '';
  document.getElementById('location').value = data.location || '';
  document.getElementById('jobUrl').value = data.jobUrl || '';
  document.getElementById('employmentType').value = data.employmentType || '';
  document.getElementById('salary').value = data.salary || '';
  document.getElementById('deadline').value = data.deadline || '';
  document.getElementById('description').value = data.description || '';
  document.getElementById('status').value = data.status || 'SAVED';
  document.getElementById('reminderOffsetHours').value = data.reminderOffsetHours || defaultPreferences.reminderOffsetHours;
  document.getElementById('notes').value = data.notes || '';
}

function hasChromeStorage() {
  return !!(typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local);
}

function loadPreferences() {
  if (!hasChromeStorage()) {
    document.getElementById('reminderOffsetHours').value = defaultPreferences.reminderOffsetHours;
    return;
  }

  chrome.storage.local.get([PREFERENCES_KEY], (result) => {
    const preferences = { ...defaultPreferences, ...(result[PREFERENCES_KEY] || {}) };
    document.getElementById('reminderOffsetHours').value = preferences.reminderOffsetHours ?? defaultPreferences.reminderOffsetHours;
  });
}

function saveJobEntry(event) {
  event.preventDefault();
  const data = gatherFormData();

  if (!data.title || !data.companyName) {
    showBanner('Job title and company are required.', true);
    return;
  }

  if (!hasChromeStorage()) {
    showBanner('Chrome storage is unavailable in this browser context.', true);
    return;
  }

  chrome.storage.local.get([STORAGE_KEY], (result) => {
    const jobs = Array.isArray(result[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
    const newJob = {
      id: crypto.randomUUID ? crypto.randomUUID() : `job-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      ...data,
      position: Date.now(),
      dateSaved: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    jobs.unshift(newJob);
    chrome.storage.local.set({ [STORAGE_KEY]: jobs }, () => {
      chrome.storage.local.set({ [PREFERENCES_KEY]: { ...defaultPreferences, ...({ reminderOffsetHours: data.reminderOffsetHours || defaultPreferences.reminderOffsetHours, notificationEnabled: true }) } }, () => {
        showBanner('Job Saved Successfully!');
        form.reset();
        setFormValues({ status: 'SAVED', reminderOffsetHours: data.reminderOffsetHours || defaultPreferences.reminderOffsetHours });
      });
    });
  });
}

async function loadPageData() {
  if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
    showBanner('Open this page in the extension popup to auto-detect job data.', true);
    return;
  }

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const [tab] = tabs;
  if (!tab || !tab.id) return;

  chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_JOB_DATA' }, (response) => {
    if (chrome.runtime.lastError) {
      showBanner('No supported job page detected. Fill the form manually.', true);
      return;
    }

    if (!response || !response.title) {
      showBanner('No job information detected. Fill in the form manually.', true);
      return;
    }

    setFormValues({
      title: response.title,
      companyName: response.companyName,
      location: response.location,
      jobUrl: response.jobUrl,
      employmentType: response.employmentType,
      salary: response.salary,
      deadline: response.deadline,
      description: response.description,
      status: 'SAVED',
      reminderOffsetHours: Number(document.getElementById('reminderOffsetHours').value || defaultPreferences.reminderOffsetHours),
    });
    showBanner('Job details detected and ready to save.');
  });
}

dashboardButton.addEventListener('click', () => {
  if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.create) {
    window.open('../dashboard/dashboard.html', '_blank');
    return;
  }
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
});

saveButton.addEventListener('click', (event) => {
  if (!form.reportValidity()) return;
  saveJobEntry(event);
});

form.addEventListener('submit', saveJobEntry);
document.getElementById('cancel-job').addEventListener('click', () => {
  form.reset();
  setFormValues({ status: 'SAVED', reminderOffsetHours: defaultPreferences.reminderOffsetHours });
  hideBanner();
});

loadPreferences();
loadPageData();
